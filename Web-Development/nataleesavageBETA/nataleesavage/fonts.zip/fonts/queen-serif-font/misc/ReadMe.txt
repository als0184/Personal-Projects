
HELLO!!
We thank you for downloading our products. If you have any queries regarding our products, do not hesitate to reach out to us and we will get back to you promptly. We are delighted that you have chosen to experience our product and hope you find it as pleasurable as we did creating it! Appreciate your support.


LICENSE:
✓ Freebies License


TERMS:
✓ 1 Number of projects
✓ Up to 1,000 items Physical objects
✓ Up to $1,000 Project value
⨉ Prohibited Digital Paid Ads Impressions
⨉ Prohibited Broadcast and streaming
⨉ Prohibited Physical advertisement
⨉ Prohibited Native app, web or game


STRICTLY PROHIBITED:
You may not re-sell, share, transfer, or redistribute this file as a separate attachment to any of your projects. This file cannot be used in a product for sale where the item contributes to the core value of the product. It may not be used in a pornographic, defamatory, or deceptive context, or in a libelous, obscene, or illegal way.


LEARN MORE: https://www.factory738.com/font-licenses/


Regards,

Wahyu Rahmawan
FactoryType Studio
Bali, Indonesia

w: www.factory738.com
m: hello@factory738.com